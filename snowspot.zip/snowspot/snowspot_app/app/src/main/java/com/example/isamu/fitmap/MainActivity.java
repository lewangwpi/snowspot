package com.example.isamu.fitmap;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.kosalgeek.android.json.JsonConverter;
import com.kosalgeek.genasync12.AsyncResponse;
import com.kosalgeek.genasync12.PostResponseAsyncTask;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, GoogleMap.OnMapClickListener, View.OnLongClickListener,AsyncResponse,GoogleMap.OnInfoWindowClickListener,LocationListener, GoogleMap.OnMapLongClickListener {

    /**
     * The desired interval for location updates. Inexact. Updates may be more or less frequent.
     */
    public static final long UPDATE_INTERVAL_IN_MILLISECONDS = 10000;

    /**
     * The fastest rate for active location updates. Exact. Updates will never be more frequent
     * than this value.
     */
    public static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS =
            UPDATE_INTERVAL_IN_MILLISECONDS / 2;

    /**
     * Stores parameters for requests to the FusedLocationProviderApi.
     */
    protected LocationRequest mLocationRequest;
    // Keys for storing activity state in the Bundle.
    protected final static String REQUESTING_LOCATION_UPDATES_KEY = "requesting-location-updates-key";
    protected final static String LOCATION_KEY = "location-key";
    protected final static String LAST_UPDATED_TIME_STRING_KEY = "last-updated-time-string-key";

    /**
     * Request code for location permission request.
     *
     * @see #onRequestPermissionsResult(int, String[], int[])
     */
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    /**
     * Flag indicating whether a requested permission has been denied after returning in
     * {@link #onRequestPermissionsResult(int, String[], int[])}.
     */
    private boolean mPermissionDenied = false;

    public GoogleMap mMap;
    public Location mLastLocation;
    public GoogleApiClient mApiClient;
    public ImageButton snowButton;
    public ArrayList<ReportFormBase> resultsList;
    public EditText searchText ;
    public SupportMapFragment mapFragment;
    public HashMap<String,ReportFormBase> markHash;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // ATTENTION: This "addApi(AppIndex.API)"was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        mApiClient = new GoogleApiClient.Builder(this)
                .addApi(LocationServices.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(AppIndex.API).build();
// Create an instance of GoogleAPIClient.




        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapAct);
        mapFragment.getMapAsync(this);
        snowButton = (ImageButton) findViewById(R.id.snowButton);
        snowButton.setOnLongClickListener(this);
        searchText = (EditText) findViewById(R.id.searchText);
        createLocationRequest();


    }


    @Override
    public void onMapReady(GoogleMap map) {
        mMap = map;
        mApiClient.connect();
        enableMyLocation();

    }

    public void onSeachClick(View v) {

        String g = searchText.getText().toString();

        Geocoder geocoder = new Geocoder(getBaseContext());
        List<Address> addresses = null;

        try {
            // Getting a maximum of 3 Address that matches the input
            // text
            addresses = geocoder.getFromLocationName(g, 3);
            if (addresses != null && !addresses.equals(""))
                search(addresses);

        } catch (Exception e) {
            Log.d(Constants.LOGNAME,e.toString());
        }
    }
    protected void search(List<Address> addresses) {

        Address address = (Address) addresses.get(0);
        double home_long = address.getLongitude();
        double home_lat = address.getLatitude();
        LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());

        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16.0f));
        LatLngBounds bounds = this.mMap.getProjection().getVisibleRegion().latLngBounds;
        getReportsFromServer(bounds);



    }
    /**
     * Enables the My Location layer if the fine location permission has been granted.
     */
    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission to access the location is missing.
            PermissionUtils.requestPermission(this, LOCATION_PERMISSION_REQUEST_CODE,
                    Manifest.permission.ACCESS_FINE_LOCATION, true);
        } else {
            if (mMap != null) {
                // Access to the location has been granted to the app.
                mMap.setMyLocationEnabled(true);
                mMap.setOnMapClickListener(this);
                mMap.setInfoWindowAdapter(new SnowInfoWin());
                mMap.setOnInfoWindowClickListener(this);
                mMap.setOnMapLongClickListener(this);
                centerMap();
            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode != LOCATION_PERMISSION_REQUEST_CODE) {
            return;
        }

        if (PermissionUtils.isPermissionGranted(permissions, grantResults,
                Manifest.permission.ACCESS_FINE_LOCATION)) {
            // Enable the my location layer if the permission has been granted.
            mPermissionDenied = false;
            enableMyLocation();
            if(!mApiClient.isConnected())
            {
                mApiClient.connect();
            }else{
                startLocationUpdates();

                downloadMarkersFromDB();
            }

        } else {
            // Display the missing permission error dialog when the fragments resume.
            mPermissionDenied = true;
        }
    }

    @Override
    protected void onResumeFragments() {
        super.onResumeFragments();
        if (mPermissionDenied) {
            // Permission was not granted, display error dialog.
            showMissingPermissionError();
            mPermissionDenied = false;
       }
    }

    /**
     * Displays a dialog with error message explaining that the location permission is missing.
     */
    private void showMissingPermissionError() {
        PermissionUtils.PermissionDeniedDialog
                .newInstance(true).show(getSupportFragmentManager(), "dialog");
    }

    @Override
    public void onResume() {
        super.onResume();  // Always call the superclass method first
        if(!mApiClient.isConnected())
        {
            mApiClient.connect();
        }

    }
    @Override
    public void onPause() {
        super.onPause();  // Always call the superclass method first
        if(mApiClient.isConnected()){
            mApiClient.disconnect();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onConnected(@Nullable Bundle bundle) {

        startLocationUpdates();

        downloadMarkersFromDB();

    }

    public void downloadMarkersFromDB(int delay){
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Do something after 5s = 5000ms
                centerMap();
            }
        }, delay);
    }
    public void downloadMarkersFromDB(){
        downloadMarkersFromDB(500);
    }

    protected void startLocationUpdates() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission to access the location is missing.
            PermissionUtils.requestPermission(this, LOCATION_PERMISSION_REQUEST_CODE,
                    Manifest.permission.ACCESS_FINE_LOCATION, true);
        } else {
            LocationServices.FusedLocationApi.requestLocationUpdates(
                    mApiClient, mLocationRequest, this);
        }

    }
    @Override
    public void onConnectionSuspended(int i) {

    }
    /**
     * Callback that fires when the location changes.
     */
    @Override
    public void onLocationChanged(Location location) {
        if ( mMap != null) {
            mLastLocation = location;

            LatLngBounds bounds = this.mMap.getProjection().getVisibleRegion().latLngBounds;
            getReportsFromServer(bounds);



        }
    }
    protected void createLocationRequest() {
        mLocationRequest = new LocationRequest();

        // Sets the desired interval for active location updates. This interval is
        // inexact. You may not receive updates at all if no location sources are available, or
        // you may receive them slower than requested. You may also receive updates faster than
        // requested if other applications are requesting location at a faster interval.
        mLocationRequest.setInterval(UPDATE_INTERVAL_IN_MILLISECONDS);

        // Sets the fastest rate for active location updates. This interval is exact, and your
        // application will never receive updates faster than this value.
        mLocationRequest.setFastestInterval(FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS);

        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {


        Log.d(Constants.LOGNAME,"Error GoogleAPI " +connectionResult.toString());
        // Return false so that we don't consume the event and the default behavior still occurs
        // (the camera animates to the user's current position).

    }
    public void centerMap(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission to access the location is missing.
            PermissionUtils.requestPermission(this, LOCATION_PERMISSION_REQUEST_CODE,
                    Manifest.permission.ACCESS_FINE_LOCATION, true);
        } else {
            mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mApiClient);
        }

        if (mLastLocation != null && mMap != null) {
            LatLng loc = new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude());
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(loc, 16.0f));
            LatLngBounds bounds = this.mMap.getProjection().getVisibleRegion().latLngBounds;
            getReportsFromServer(bounds);


        }
    }

    @Override
    public void onMapClick(LatLng latLng) {
        Location temp = new Location(LocationManager.GPS_PROVIDER);
        temp.setLatitude(latLng.latitude);
        temp.setLongitude(latLng.longitude);

        startForm(true,0,0,temp);


    }

    public void onClickSnow(View v) {
        startForm(true,0,0);


    }
    public boolean onLongClick(View v) {
        startForm(true,0,1);
        return true;

    }
    public void startForm(boolean newForm, int indexType, int indexDepth, Location formLoca, String formaddress,String imageUrl, int id){
        Intent intentToReport = new Intent(this, reportActivity.class);
        intentToReport.putExtra(Constants.LOCATION_DATA_EXTRA, formLoca);
        intentToReport.putExtra("newForm",newForm);
        intentToReport.putExtra("indexType",indexType);
        intentToReport.putExtra("indexDepth", indexDepth);
        intentToReport.putExtra("address", formaddress);
        intentToReport.putExtra("image_url", Constants.URL_SITE + imageUrl);
        intentToReport.putExtra("id",id);
        startActivity(intentToReport);
    }

    public void startForm(boolean newForm, int indexType, int indexDepth, Location formLoca, String formaddress,String imageUrl){
        Intent intentToReport = new Intent(this, reportActivity.class);
        intentToReport.putExtra(Constants.LOCATION_DATA_EXTRA, formLoca);
        intentToReport.putExtra("newForm",newForm);
        intentToReport.putExtra("indexType",indexType);
        intentToReport.putExtra("indexDepth", indexDepth);
        intentToReport.putExtra("address", formaddress);
        intentToReport.putExtra("image_url", Constants.URL_SITE + imageUrl);
        startActivity(intentToReport);
    }

    public void startForm(boolean newForm, int indexType, int indexDepth, Location formLoca, String formaddress){
        startForm(newForm, indexType, indexDepth, formLoca, formaddress,"");
    }
    public void startForm(boolean newForm, int indexType, int indexDepth){
        startForm(newForm,indexType,indexDepth,mLastLocation,"");
    }
    public void startForm(boolean newForm, int indexType, int indexDepth, Location formLoca){
        startForm(newForm,indexType,indexDepth,formLoca,"");
    }
    @Override
    protected void onStart() {
        super.onStart();
        mApiClient.connect();
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "Main Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.example.isamu.fitmap/http/host/path")
        );
        AppIndex.AppIndexApi.start(mApiClient, viewAction);
    }

    @Override
    protected void onStop() {
        super.onStop();
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "Main Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.example.isamu.fitmap/http/host/path")
        );
        AppIndex.AppIndexApi.end(mApiClient, viewAction);
        if (mApiClient.isConnected()) {
            mApiClient.disconnect();
        }
    }
    protected void getReportsFromServer(LatLngBounds bounds)
    {
        HashMap<String,String> mapQuerry = new HashMap<>();
        LatLng ne =  bounds.northeast;
        LatLng sw = bounds.southwest;
        if(ne.latitude > sw.latitude)
        {
            mapQuerry.put("latitude_max",String.valueOf(ne.latitude));
            mapQuerry.put("latitude_min",String.valueOf(sw.latitude));
        }else
        {
            mapQuerry.put("latitude_max",String.valueOf(sw.latitude));
            mapQuerry.put("latitude_min",String.valueOf(ne.latitude));
        }
        if(ne.longitude > sw.longitude)
        {
            mapQuerry.put("longitude_max",String.valueOf(ne.longitude));
            mapQuerry.put("longitude_min",String.valueOf(sw.longitude));
        }else
        {
            mapQuerry.put("longitude_max",String.valueOf(sw.longitude));
            mapQuerry.put("longitude_min",String.valueOf(ne.longitude));
        }

        PostResponseAsyncTask taskSend =  new PostResponseAsyncTask(MainActivity.this,mapQuerry,this);
        taskSend.execute(Constants.URL_QUERY);


    }

    @Override
    public void processFinish(String s) {
        if(s != null && !s.contains("null")) {


            try {

                String cropString = TextUtils.substring(s,s.indexOf("[{"),s.indexOf("}]")+2);
                resultsList = new JsonConverter<ReportFormBase>().toArrayList(cropString, ReportFormBase.class);

                Log.d(Constants.LOGNAME,cropString);
            } catch (Exception e) {
                Log.d(Constants.LOGNAME,e.toString());

            }

            updateMarkers();
        }
    }

    public void onCenterClick(View v){
        centerMap();


    }
    public void updateMarkers(){
        if (resultsList != null)
        {
            if (markHash != null){

                mMap.clear();
            }
            markHash = new HashMap<>(resultsList.size());
            for(ReportFormBase item:resultsList){
                String keyString = addMakerFromForm(item);
                if(keyString != null){
                    markHash.put(keyString,item);
                }
            }
        }
    }
    public void refreshMakers(){
        if (markHash != null && mMap != null){
            mMap.clear();
            for(HashMap.Entry<String,ReportFormBase> item: markHash.entrySet()){

                addMakerFromForm(item.getValue());
            }
        }
    }

    @Override
    public void onInfoWindowClick(Marker marker) {

        if(markHash != null){
            ReportFormBase currentItem = markHash.get(marker.getId());
            if(currentItem.user_type.contains("user")) {
                Location temp = new Location(LocationManager.GPS_PROVIDER);
                LatLng latLong = marker.getPosition();
                temp.setLatitude(latLong.latitude);
                temp.setLongitude(latLong.longitude);
                Resources res = getResources();
                String[] typesSnowtemp = res.getStringArray(R.array.typeSnow_array);
                List<String> typesSnowList = Arrays.asList(typesSnowtemp);
                String[] depthSnowtemp = res.getStringArray(R.array.depth_array);
                List<String> depthSnowList = Arrays.asList(depthSnowtemp);
                int indexDepth = depthSnowList.indexOf(currentItem.depth);
                int indexType = typesSnowList.indexOf(currentItem.type);
                if (indexDepth >= 0 && indexType >= 0) {
                    startForm(false, indexType, indexDepth, temp, currentItem.address,currentItem.image_url,currentItem.id);
                } else {
                    startForm(false, 0, 0, temp, currentItem.address,currentItem.image_url,currentItem.id);
                }
            }
        }




    }
    public String addMakerFromForm(ReportFormBase item) {
        try {
            double pinLat = Double.parseDouble(item.latitude);
            double pinLon = Double.parseDouble(item.longitude);
            LatLng latlonCurrent = new LatLng(pinLat, pinLon);
            BitmapDescriptor pinIcon;
            Marker temp;
            if(item.user_type.contains("user") ) {

                if (item.type.contains("Snow")) {
                    pinIcon = BitmapDescriptorFactory.fromResource(R.drawable.snow);
                } else if (item.type.contains("Ice")) {
                    pinIcon = BitmapDescriptorFactory.fromResource(R.drawable.ice);
                } else if (item.type.contains("Water")) {
                    pinIcon = BitmapDescriptorFactory.fromResource(R.drawable.water);
                } else {
                    pinIcon = BitmapDescriptorFactory.fromResource(R.drawable.arrow);
                }

                temp = mMap.addMarker(new MarkerOptions()
                        .position(latlonCurrent)
                        .title(item.depth + " " + item.type)
                        .snippet(item.address)
                        .icon(pinIcon));
            } else{
                pinIcon = BitmapDescriptorFactory.fromResource(R.drawable.plow);
                temp  = mMap.addMarker(new MarkerOptions()
                        .position(latlonCurrent)
                        .title(item.user_type)
                        .snippet("")
                        .icon(pinIcon));
            }
            return temp.getId();
        } catch (Exception e) {
            Log.d(Constants.LOGNAME, e.toString());

            return null;
        }
    }

    @Override
    public void onMapLongClick(LatLng latLng) {
        Location temp = new Location(LocationManager.GPS_PROVIDER);
        temp.setLatitude(latLng.latitude);
        temp.setLongitude(latLng.longitude);
        startForm(true,0,1,temp);
    }

    class SnowInfoWin implements GoogleMap.InfoWindowAdapter {
        private final View mContents;

        SnowInfoWin()
        {
            mContents = getLayoutInflater().inflate(R.layout.custom_info_contents,null);
        }

        @Override
        public View getInfoWindow(Marker marker) {
            return null;
        }

        @Override
        public View getInfoContents(Marker marker) {

            String title = marker.getTitle();
            TextView titleUi = ((TextView) mContents.findViewById(R.id.title));
            if (title != null) {
                // Spannable string allows us to edit the formatting of the text.
                SpannableString titleText = new SpannableString(title);
                titleText.setSpan(new ForegroundColorSpan(Color.RED), 0, titleText.length(), 0);
                titleUi.setText(titleText);
            } else {
                titleUi.setText("");
            }

            String snippet = marker.getSnippet();
            TextView snippetUi = ((TextView) mContents.findViewById(R.id.snippet));
            if (snippet != null && snippet.length() > 12) {
                SpannableString snippetText = new SpannableString(snippet);
                snippetText.setSpan(new ForegroundColorSpan(Color.BLUE), 0, snippet.length(), 0);
                snippetUi.setText(snippetText);
            } else {
                snippetUi.setText("");
            }
            return mContents;
        }
    }


}
