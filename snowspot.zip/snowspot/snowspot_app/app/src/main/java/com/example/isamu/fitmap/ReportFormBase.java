package com.example.isamu.fitmap;

import com.google.gson.annotations.SerializedName;

/**
 * Created by isamu on 4/17/2016.
 */
public class ReportFormBase {

    @SerializedName("id")
    public int id;

    @SerializedName("depth")
    public String depth;

    @SerializedName("type")
    public String type;

    @SerializedName("latitude")
    public String latitude;

    @SerializedName("longitude")
    public String longitude;

    @SerializedName("address")
    public String address;

    @SerializedName("image")
    public String image;

    @SerializedName("image_url")
    public String image_url;

    @SerializedName("timestamp")
    public String timestamp;

    @SerializedName("user_type")
    public String user_type;



}
