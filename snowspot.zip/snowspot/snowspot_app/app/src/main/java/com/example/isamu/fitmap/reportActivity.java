package com.example.isamu.fitmap;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.ResultReceiver;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;
import com.kosalgeek.android.photoutil.ImageBase64;
import com.kosalgeek.android.photoutil.ImageLoader;
import com.kosalgeek.genasync12.AsyncResponse;
import com.kosalgeek.genasync12.PostResponseAsyncTask;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;


public class reportActivity extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {
    Spinner spinnerType;
    Spinner spinnerDepth;
    String currentPhotoName;
    ImageView mPhotoView;
    File mPhotoFile;
    protected Location mLastLocation;
    private AddressResultReceiver mResultReceiver;
    EditText addrsTV;
    Intent receivedIntent;
    ImageButton mPhotoButton;
    Intent captureImage;
    Uri mUriPhoto;
    public GoogleApiClient mApiClient;
    Button mUploadButton;
    boolean newForm;
    Bitmap mbitmap;
    String urlPhoto;
    LocalAsyncResponse localResp;
    int idDB = 0;
    private static final int REQUEST_PHOTO = 2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        PackageManager packageManager = this.getPackageManager();
        spinnerType = (Spinner) findViewById(R.id.spinnerTypeSnow);
        spinnerDepth = (Spinner) findViewById(R.id.spinnerDepth);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterType = ArrayAdapter.createFromResource(this,
                R.array.typeSnow_array, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adapterDepth = ArrayAdapter.createFromResource(this,
                R.array.depth_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapterType.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapterDepth.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinnerType.setAdapter(adapterType);
        spinnerDepth.setAdapter(adapterDepth);
        //Get information about the
        receivedIntent = getIntent();
        mLastLocation = receivedIntent.getParcelableExtra(
                Constants.LOCATION_DATA_EXTRA);
        newForm = receivedIntent.getBooleanExtra("newForm", true);
        int indexType = receivedIntent.getIntExtra("indexType", 0);
        int indexDepth = receivedIntent.getIntExtra("indexDepth", 0);
        spinnerType.setSelection(indexType);
        spinnerDepth.setSelection(indexDepth);
        String localaddress = " ";
        if (!newForm) {
            localaddress = receivedIntent.getStringExtra("address");
        }
        createPhotoFileName();
        captureImage = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        mPhotoButton = (ImageButton) findViewById(R.id.cameraButton);
        boolean canTakePhoto = mPhotoFile != null &&
                captureImage.resolveActivity(packageManager) != null;
        mPhotoButton.setEnabled(canTakePhoto);
        if (canTakePhoto) {
            mUriPhoto = Uri.fromFile(mPhotoFile);
            captureImage.putExtra(MediaStore.EXTRA_OUTPUT, mUriPhoto);
        }
        mPhotoView = (ImageView) findViewById(R.id.imageSnow);


        mResultReceiver = new AddressResultReceiver(new Handler());
        // ATTENTION: This "addApi(AppIndex.API)"was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        mApiClient = new GoogleApiClient.Builder(this)
                .addApi(LocationServices.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(AppIndex.API).build();
// Create an instance of GoogleAPIClient.

        mUploadButton = (Button) findViewById(R.id.uploadButton);
        mApiClient.connect();
        addrsTV = (EditText) findViewById(R.id.editTextAddr);
        if (newForm) {
            addrsTV.setText(getString(R.string.lookingAddr), TextView.BufferType.NORMAL);
            mPhotoView.setImageDrawable(null);
        } else {
            addrsTV.setText(localaddress, TextView.BufferType.NORMAL);
            urlPhoto = receivedIntent.getStringExtra("image_url");
            if(urlPhoto != null){
                Picasso.with(this).load(urlPhoto).into(mPhotoView);
            }else{
                mPhotoView.setImageDrawable(null);
            }
            mUploadButton.setText(R.string.update);
            idDB = receivedIntent.getIntExtra("id",0);

        }


        addrsTV.setEnabled(false);
        localResp = new LocalAsyncResponse();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_report, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public void onUploadClick(View v){
        mUploadButton.setEnabled(false);
        HashMap<String,String> formToSend = encodeForm();
        PostResponseAsyncTask taskSend =  new PostResponseAsyncTask(reportActivity.this,formToSend,localResp);

        taskSend.execute(Constants.URL_ADD);


    }


    public void onCameraClick(View v){
        if(mUriPhoto != null){
            startActivityForResult(captureImage, REQUEST_PHOTO);
        }

    }
    public boolean createPhotoFileName() {
        if (currentPhotoName == null) {
            GregorianCalendar gcal = new GregorianCalendar();
            gcal.get(Calendar.DAY_OF_MONTH);
            StringBuilder dateString = new StringBuilder();
            dateString.append(gcal.get(Calendar.YEAR));
            dateString.append(gcal.get(Calendar.MONTH));
            dateString.append(gcal.get(Calendar.DAY_OF_MONTH));


            currentPhotoName = "IMG_" + String.valueOf(mLastLocation.getLatitude()) + "_" + String.valueOf(mLastLocation.getLongitude()) + "_" + dateString.toString() + ".jpg";
        }
        File externalDir = this.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (mPhotoFile == null){
            mPhotoFile = new File(externalDir, currentPhotoName);
        }
        return true;
    }
    private void updatePhotoView() {
        if (mPhotoFile == null || !mPhotoFile.exists()) {
            mPhotoView.setImageDrawable(null);
        } else {
            mbitmap = PictureUtils.getScaledBitmap(
                    mPhotoFile.getPath(), this);


            try {
                mbitmap = ImageLoader.init().from(mPhotoFile.getPath()).requestSize(512,512).getBitmap();
            } catch (FileNotFoundException e) {
                Log.e(Constants.LOGNAME,"Image Loading: " + e.toString());
            }
            mPhotoView.setImageBitmap(mbitmap);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK) {
            return;
        }



         if (requestCode == REQUEST_PHOTO) {
            updatePhotoView();
        }
    }

    @Override
    public void onConnected(Bundle bundle) {
        if(newForm) {
            startIntentService();
        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    public HashMap<String,String> encodeForm() {
        HashMap<String,String> data =new HashMap<>() ;

        data.put("address",addrsTV.getText().toString());
        data.put("type",spinnerType.getSelectedItem().toString());
        data.put("depth",spinnerDepth.getSelectedItem().toString());
        data.put("latitude",String.valueOf(mLastLocation.getLatitude()));
        data.put("longitude",String.valueOf(mLastLocation.getLongitude()));
        if(!newForm)
        {
            data.put("id",String.valueOf(idDB));
        }
        if (mbitmap != null) {
            String imageBase64 = ImageBase64.encode(mbitmap);

            data.put("image",imageBase64);
        }
        return data;
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Toast.makeText(this, "Error GoogleAPI " + connectionResult.toString(), Toast.LENGTH_SHORT).show();
        // Return false so that we don't consume the event and the default behavior still occurs
        // (the camera animates to the user's current position).

    }
    protected void startIntentService() {
        Intent intent = new Intent(this, FetchAddressIntentService.class);
        intent.putExtra(Constants.RECEIVER, mResultReceiver);
        intent.putExtra(Constants.LOCATION_DATA_EXTRA, mLastLocation);
        showToast(getString(R.string.lookingAddr));
        startService(intent);
    }

    /**
     * Shows a toast with the given text.
     */
    protected void showToast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        mApiClient.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "report Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.example.isamu.fitmap/http/host/path")
        );
        AppIndex.AppIndexApi.start(mApiClient, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "report Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.example.isamu.fitmap/http/host/path")
        );
        AppIndex.AppIndexApi.end(mApiClient, viewAction);
        mApiClient.disconnect();
    }


    class AddressResultReceiver extends ResultReceiver {
        public AddressResultReceiver(Handler handler) {
            super(handler);
        }

        @Override
        protected void onReceiveResult(int resultCode, Bundle resultData) {

            // Display the address string
            // or an error message sent from the intent service.
            String temOut = resultData.getString(Constants.RESULT_DATA_KEY);
            EditText addrsTV = (EditText) findViewById(R.id.editTextAddr);


            // Show a toast message if an address was found.
            if (resultCode == Constants.SUCCESS_RESULT && temOut != null) {
                addrsTV.setText(temOut, TextView.BufferType.SPANNABLE);
                addrsTV.setEnabled(true);
            }

        }


    }
    private class LocalAsyncResponse implements AsyncResponse {

        @Override
        public void processFinish(String s) {
            if(s.contains("Information Received")) {
                if(newForm) {
                    Toast.makeText(reportActivity.this, getString(R.string.uploadOK), Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(reportActivity.this, getString(R.string.updateOK), Toast.LENGTH_LONG).show();
                }
                    finish();
            }Log.d(Constants.LOGNAME,s);
            mUploadButton.setEnabled(true);
        }
    }

}
