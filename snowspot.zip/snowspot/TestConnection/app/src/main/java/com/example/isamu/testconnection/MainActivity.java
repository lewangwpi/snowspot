package com.example.isamu.testconnection;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.kosalgeek.genasync12.AsyncResponse;
import com.kosalgeek.genasync12.PostResponseAsyncTask;

import java.util.HashMap;


public class MainActivity extends AppCompatActivity {
    private final static String WEBSITE = "http://isamubr.net16.net/index.php";
    Button sendButton;
    EditText textSend;
    LocalAsyncResponse localResp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sendButton = (Button) findViewById(R.id.sendButton);
        textSend = (EditText) findViewById(R.id.textToSend);
        localResp = new LocalAsyncResponse();
    }
    public void onSendClick(View v){
        String text = textSend.getText().toString();
        HashMap<String,String> dataToSend = new HashMap<>();
        dataToSend.put("TAG",text);
        PostResponseAsyncTask taskSend = new PostResponseAsyncTask(MainActivity.this,dataToSend,localResp);
        taskSend.execute(WEBSITE);

    }
    private class LocalAsyncResponse implements AsyncResponse {

        @Override
        public void processFinish(String s) {
            Toast.makeText(MainActivity.this,s,Toast.LENGTH_LONG).show();
        }
    }
}
