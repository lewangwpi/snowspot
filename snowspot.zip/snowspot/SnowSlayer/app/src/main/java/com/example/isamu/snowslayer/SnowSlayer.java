package com.example.isamu.snowslayer;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.kosalgeek.android.json.JsonConverter;
import com.kosalgeek.genasync12.AsyncResponse;
import com.kosalgeek.genasync12.PostResponseAsyncTask;

import java.util.ArrayList;
import java.util.HashMap;

public class SnowSlayer extends AppCompatActivity implements OnMapReadyCallback,  GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, GoogleMap.OnMapClickListener, View.OnLongClickListener,AsyncResponse,GoogleMap.OnInfoWindowClickListener,LocationListener  {

    /**
     * The desired interval for location updates. Inexact. Updates may be more or less frequent.
     */
    public static final long UPDATE_INTERVAL_IN_MILLISECONDS = 15000;

    /**
     * The fastest rate for active location updates. Exact. Updates will never be more frequent
     * than this value.
     */
    public static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS =
            UPDATE_INTERVAL_IN_MILLISECONDS / 2;

    public static final String plowID = "snowplow01";
    // Keys for storing activity state in the Bundle.
    protected final static String REQUESTING_LOCATION_UPDATES_KEY = "requesting-location-updates-key";
    protected final static String LOCATION_KEY = "location-key";
    protected final static String LAST_UPDATED_TIME_STRING_KEY = "last-updated-time-string-key";
    /**
     * Stores parameters for requests to the FusedLocationProviderApi.
     */
    protected LocationRequest mLocationRequest;
    /**
     * Request code for location permission request.
     *
     * @see #onRequestPermissionsResult(int, String[], int[])
     */
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    public HashMap<String,ReportFormBase> markHash;
    /**
     * Flag indicating whether a requested permission has been denied after returning in
     * {@link #onRequestPermissionsResult(int, String[], int[])}.
     */
    private boolean mPermissionDenied = false;

    public GoogleMap mMap;
    public Location mLastLocation;
    public GoogleApiClient mApiClient;
    public ImageButton snowButton;
    public ArrayList<ReportFormBase> resultsList;

    public SupportMapFragment mapFragment;
    public QueryResponse queryResponse;
    public DeleteResponse deleteResponse;
    public UpdateLocationResponse updateLocationResponse;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_snow_slayer);


        mApiClient = new GoogleApiClient.Builder(this)
                .addApi(LocationServices.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(AppIndex.API).build();
// Create an instance of GoogleAPIClient.


        mApiClient.connect();

        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapAct);
        mapFragment.getMapAsync(this);
        createLocationRequest();

        queryResponse = new QueryResponse();
        deleteResponse = new DeleteResponse();
        updateLocationResponse = new UpdateLocationResponse();
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        enableMyLocation();
    }
    public void centerMap(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission to access the location is missing.
            PermissionUtils.requestPermission(this, LOCATION_PERMISSION_REQUEST_CODE,
                    Manifest.permission.ACCESS_FINE_LOCATION, true);
        } else {
            mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mApiClient);
        }

        if (mLastLocation != null && mMap != null) {
            LatLng loc = new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude());
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(loc, 16.0f));
            LatLngBounds bounds = this.mMap.getProjection().getVisibleRegion().latLngBounds;
            getReportsFromServer(bounds);


        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        centerMap();
       startLocationUpdates();
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Do something after 5s = 5000ms
                centerMap();
            }
        }, 500);




    }
    protected void startLocationUpdates() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission to access the location is missing.
            PermissionUtils.requestPermission(this, LOCATION_PERMISSION_REQUEST_CODE,
                    Manifest.permission.ACCESS_FINE_LOCATION, true);
        } else {
            if(mApiClient.isConnected()) {
                LocationServices.FusedLocationApi.requestLocationUpdates(
                        mApiClient, mLocationRequest, this);
            }else{
                mApiClient.connect();
            }
        }

    }
    /**
     * Callback that fires when the location changes.
     */
    @Override
    public void onLocationChanged(Location location) {
        if ( mMap != null) {
            mLastLocation = location;
            LatLngBounds bounds = this.mMap.getProjection().getVisibleRegion().latLngBounds;
            getReportsFromServer(bounds);
            updateLocationinServer(location);


        }
    }

    public void updateLocationinServer(Location location)
    {
        HashMap<String,String> locToSend = new HashMap<>();
        locToSend.put("latitude",String.valueOf(location.getLatitude()));
        locToSend.put("longitude",String.valueOf(location.getLongitude()));

        locToSend.put("user_type", plowID);
        PostResponseAsyncTask taskSend =  new PostResponseAsyncTask(SnowSlayer.this,locToSend,updateLocationResponse);
        taskSend.execute(Constants.URL_UPDATE);
    }

    protected void createLocationRequest() {
        mLocationRequest = new LocationRequest();

        // Sets the desired interval for active location updates. This interval is
        // inexact. You may not receive updates at all if no location sources are available, or
        // you may receive them slower than requested. You may also receive updates faster than
        // requested if other applications are requesting location at a faster interval.
        mLocationRequest.setInterval(UPDATE_INTERVAL_IN_MILLISECONDS);

        // Sets the fastest rate for active location updates. This interval is exact, and your
        // application will never receive updates faster than this value.
        mLocationRequest.setFastestInterval(FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS);

        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }
    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onInfoWindowClick(Marker marker) {
        if(markHash != null){
            ReportFormBase currentItem = markHash.get(marker.getId());
            HashMap<String,String> deleteReq = new HashMap<>();
            deleteReq.put("id", Integer.toString(currentItem.id));
            PostResponseAsyncTask taskSend =  new PostResponseAsyncTask(SnowSlayer.this,deleteReq,deleteResponse);
            taskSend.execute(Constants.URL_DELETE);


        }



    }

    /**
     * Called when a view has been clicked and held.
     *
     * @param v The view that was clicked and held.
     * @return true if the callback consumed the long click, false otherwise.
     */
    @Override
    public boolean onLongClick(View v) {
        return false;
    }

    @Override
    public void onMapClick(LatLng latLng) {

    }
    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission to access the location is missing.
            PermissionUtils.requestPermission(this, LOCATION_PERMISSION_REQUEST_CODE,
                    Manifest.permission.ACCESS_FINE_LOCATION, true);
        } else {
            if (mMap != null) {
                // Access to the location has been granted to the app.
                mMap.setMyLocationEnabled(true);
                //mMap.setOnMapClickListener(this);
                mMap.setInfoWindowAdapter(new SnowInfoWin());
                mMap.setOnInfoWindowClickListener(this);
                centerMap();
            }
        }
    }
    public  void getReportsFromServer()
    {
       if (this.mMap != null) {
           LatLngBounds bounds = this.mMap.getProjection().getVisibleRegion().latLngBounds;
           getReportsFromServer(bounds);
       }
    }

    public void getReportsFromServer(LatLngBounds bounds)
    {
        HashMap<String,String> mapQuerry = new HashMap<>();
        LatLng ne =  bounds.northeast;
        LatLng sw = bounds.southwest;
        if(ne.latitude > sw.latitude)
        {
            mapQuerry.put("latitude_max",String.valueOf(ne.latitude));
            mapQuerry.put("latitude_min",String.valueOf(sw.latitude));
        }else
        {
            mapQuerry.put("latitude_max",String.valueOf(sw.latitude));
            mapQuerry.put("latitude_min",String.valueOf(ne.latitude));
        }
        if(ne.longitude > sw.longitude)
        {
            mapQuerry.put("longitude_max",String.valueOf(ne.longitude));
            mapQuerry.put("longitude_min",String.valueOf(sw.longitude));
        }else
        {
            mapQuerry.put("longitude_max",String.valueOf(sw.longitude));
            mapQuerry.put("longitude_min",String.valueOf(ne.longitude));
        }

        PostResponseAsyncTask taskSend =  new PostResponseAsyncTask(SnowSlayer.this,mapQuerry,this);
        taskSend.execute(Constants.URL_QUERY);


    }
    @Override
    public void processFinish(String s) {
        if(s != null && !s.contains("null")) {


            try {

                String cropString = TextUtils.substring(s,s.indexOf("[{"),s.indexOf("}]")+2);
                resultsList = new JsonConverter<ReportFormBase>().toArrayList(cropString, ReportFormBase.class);
                Log.d(Constants.LOGNAME,s);
            } catch (Exception e) {
                Log.d(Constants.LOGNAME,e.toString());

            }

            updateMarkers();
        }
    }
    public void updateMarkers(){
        if (resultsList != null)
        {
            if (markHash != null){

                mMap.clear();
            }
            markHash = new HashMap<>(resultsList.size());
            for(ReportFormBase item:resultsList){
                String keyString = addMakerFromForm(item);
                if(keyString != null){
                    markHash.put(keyString,item);
                }
            }
            mMap.addCircle(new CircleOptions()
                    .center(new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude()))
                    .radius(1000));
        }
    }

    public String addMakerFromForm(ReportFormBase item) {
        try {


            double pinLat = Double.parseDouble(item.latitude);
            double pinLon = Double.parseDouble(item.longitude);
            LatLng latlonCurrent = new LatLng(pinLat, pinLon);
            BitmapDescriptor pinIcon;
            Marker temp;
            if(item.user_type.contains("user") ) {

                if (item.type.contains("Snow")) {
                    pinIcon = BitmapDescriptorFactory.fromResource(R.drawable.snow);
                } else if (item.type.contains("Ice")) {
                    pinIcon = BitmapDescriptorFactory.fromResource(R.drawable.ice);
                } else if (item.type.contains("Water")) {
                    pinIcon = BitmapDescriptorFactory.fromResource(R.drawable.water);
                } else {
                    pinIcon = BitmapDescriptorFactory.fromResource(R.drawable.arrow);
                }

                temp = mMap.addMarker(new MarkerOptions()
                        .position(latlonCurrent)
                        .title(item.depth + " " + item.type)
                        .snippet(item.address)
                        .icon(pinIcon));
            } else{
                pinIcon = BitmapDescriptorFactory.fromResource(R.drawable.plow);
                temp  = mMap.addMarker(new MarkerOptions()
                        .position(latlonCurrent)
                        .title(item.user_type)
                        .snippet("")
                        .icon(pinIcon));
            }
            return temp.getId();
        } catch (Exception e) {
            Log.d(Constants.LOGNAME, e.toString());

            return null;
        }
    }

    class DeleteResponse implements  AsyncResponse{

        @Override
        public void processFinish(String s) {
            if(s != null && !s.contains("null")){
                Log.d(Constants.LOGNAME,"DeleteResponse: " + s);
                if(s.contains("successfully")){
                    Toast.makeText(SnowSlayer.this,"Deleted Successfully", Toast.LENGTH_LONG).show();

                    getReportsFromServer();
                }
            }
        }
    }
    class UpdateLocationResponse implements  AsyncResponse{

        @Override
        public void processFinish(String s) {
            if(s != null && !s.contains("null")){
                Log.d(Constants.LOGNAME,"UpdateLocationResponse: " + s);
                int startPoint = s.indexOf("-->")+3;
                int endPoint = s.indexOf("<--");

                String numberStr = TextUtils.substring(s,startPoint,endPoint);
                int numberReports = Integer.parseInt(numberStr);
                if (numberReports > 2) {
                    Toast.makeText(SnowSlayer.this, "Warning! Found "+  numberStr + " reports in the area", Toast.LENGTH_LONG).show();
                }
            }
        }
    }
    class QueryResponse implements  AsyncResponse {
        @Override
        public void processFinish(String s) {
            if(s != null && !s.contains("null")){



                    try {

                        String cropString = TextUtils.substring(s,s.indexOf("[{"),s.indexOf("}]")+2);
                        resultsList = new JsonConverter<ReportFormBase>().toArrayList(cropString, ReportFormBase.class);
                        Toast.makeText(SnowSlayer.this, cropString, Toast.LENGTH_LONG).show();
                    } catch (Exception e) {
                        Log.d(Constants.LOGNAME,e.toString());
                        Toast.makeText(SnowSlayer.this, e.toString(), Toast.LENGTH_LONG).show();
                    }

                    updateMarkers();
            }

        }
    }
    class SnowInfoWin implements GoogleMap.InfoWindowAdapter {
        private final View mContents;

        SnowInfoWin()
        {
            mContents = getLayoutInflater().inflate(R.layout.custom_info_contents,null);
        }

        @Override
        public View getInfoWindow(Marker marker) {
            return null;
        }

        @Override
        public View getInfoContents(Marker marker) {

            String title = marker.getTitle();
            TextView titleUi = ((TextView) mContents.findViewById(R.id.title));
            if (title != null) {
                // Spannable string allows us to edit the formatting of the text.
                SpannableString titleText = new SpannableString(title);
                titleText.setSpan(new ForegroundColorSpan(Color.RED), 0, titleText.length(), 0);
                titleUi.setText(titleText);
            } else {
                titleUi.setText("");
            }

            String snippet = marker.getSnippet();
            TextView snippetUi = ((TextView) mContents.findViewById(R.id.snippet));
            if (snippet != null && snippet.length() > 12) {
                SpannableString snippetText = new SpannableString(snippet);
                snippetText.setSpan(new ForegroundColorSpan(Color.BLUE), 0, snippet.length(), 0);
                snippetUi.setText(snippetText);
            } else {
                snippetUi.setText("");
            }
            return mContents;
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        stopLocationUpdates();
    }

    protected void stopLocationUpdates() {
        if (mApiClient.isConnected()){
            LocationServices.FusedLocationApi.removeLocationUpdates(
                    mApiClient, this);
            mApiClient.disconnect();
            }
    }
    @Override
    public void onResume() {
        super.onResume();
        if (mApiClient.isConnected() ) {
            startLocationUpdates();
        }else{
            mApiClient.connect();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        stopLocationUpdates();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode != LOCATION_PERMISSION_REQUEST_CODE) {
            return;
        }

        if (PermissionUtils.isPermissionGranted(permissions, grantResults,
                Manifest.permission.ACCESS_FINE_LOCATION)) {
            // Enable the my location layer if the permission has been granted.
            mPermissionDenied = false;
            enableMyLocation();
            if(!mApiClient.isConnected())
            {
                mApiClient.connect();
            }else{
                startLocationUpdates();

               centerMap();
            }

        } else {
            // Display the missing permission error dialog when the fragments resume.
            mPermissionDenied = true;
        }
    }
    @Override
    protected void onResumeFragments() {
        super.onResumeFragments();
        if (mPermissionDenied) {
            // Permission was not granted, display error dialog.
            showMissingPermissionError();
            mPermissionDenied = false;
        }
    }
    /**
     * Displays a dialog with error message explaining that the location permission is missing.
     */
    private void showMissingPermissionError() {
        PermissionUtils.PermissionDeniedDialog
                .newInstance(true).show(getSupportFragmentManager(), "dialog");
    }

}
