package com.example.isamu.snowslayer;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.ResultReceiver;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;
import com.kosalgeek.android.photoutil.ImageBase64;
import com.kosalgeek.genasync12.AsyncResponse;
import com.kosalgeek.genasync12.PostResponseAsyncTask;

import java.io.File;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;


public class reportActivity extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {
    Spinner spinnerType;
    Spinner spinnerDepth;
    String currentPhotoName;
    ImageView mPhotoView;
    File mPhotoFile;
    protected Location mLastLocation;
    private AddressResultReceiver mResultReceiver;
    EditText addrsTV;
    Intent receivedIntent;
    ImageButton mPhotoButton;
    Intent captureImage;
    Uri mUriPhoto;
    public GoogleApiClient mApiClient;
    Button mUploadButton;
    boolean newForm;
    Bitmap mbitmap;

    LocalAsyncResponse localResp;
    private static final int REQUEST_PHOTO = 2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        PackageManager packageManager = this.getPackageManager();
        spinnerType = (Spinner) findViewById(R.id.spinnerTypeSnow);
        spinnerDepth = (Spinner) findViewById(R.id.spinnerDepth);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterType = ArrayAdapter.createFromResource(this,
                R.array.typeSnow_array, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adapterDepth = ArrayAdapter.createFromResource(this,
                R.array.depth_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapterType.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapterDepth.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinnerType.setAdapter(adapterType);
        spinnerDepth.setAdapter(adapterDepth);
        //Get information about the
        receivedIntent = getIntent();
        mLastLocation = receivedIntent.getParcelableExtra(
                Constants.LOCATION_DATA_EXTRA);
        newForm = receivedIntent.getBooleanExtra("newForm",true);
        int indexType = receivedIntent.getIntExtra("indexType", 0);
            int indexDepth = receivedIntent.getIntExtra("indexDepth", 0);
            spinnerType.setSelection(indexType);
            spinnerDepth.setSelection(indexDepth);
        String localaddress = " ";
        if(!newForm){
            localaddress = receivedIntent.getStringExtra("address");
        }
        createPhotoFileName();
        captureImage = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        mPhotoButton = (ImageButton) findViewById(R.id.cameraButton);
        boolean canTakePhoto = mPhotoFile != null &&
                captureImage.resolveActivity(packageManager) != null;
        mPhotoButton.setEnabled(canTakePhoto);
        if(canTakePhoto){
            mUriPhoto = Uri.fromFile(mPhotoFile);
            captureImage.putExtra(MediaStore.EXTRA_OUTPUT,mUriPhoto);
        }
        mPhotoView = (ImageView) findViewById(R.id.imageSnow);
        updatePhotoView();


        mResultReceiver = new AddressResultReceiver(new Handler());
        mApiClient = new GoogleApiClient.Builder(this)
                .addApi(LocationServices.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();
// Create an instance of GoogleAPIClient.

        mUploadButton = (Button) findViewById(R.id.uploadButton);
        mApiClient.connect();
        addrsTV = (EditText) findViewById(R.id.editTextAddr);
        if(newForm) {
            addrsTV.setText(getString(R.string.lookingAddr), TextView.BufferType.NORMAL);
        }else{
            addrsTV.setText(localaddress,TextView.BufferType.NORMAL);
        }
        addrsTV.setEnabled(false);
        localResp = new LocalAsyncResponse();
    }


    public void onUploadClick(View v){
        mUploadButton.setEnabled(false);
        HashMap<String,String> formToSend = encodeForm();
        PostResponseAsyncTask taskSend =  new PostResponseAsyncTask(reportActivity.this,formToSend,localResp);

        //taskSend.execute(Constants.URL_ADD);


    }


    public void onCameraClick(View v){
        if(mUriPhoto != null){
            startActivityForResult(captureImage, REQUEST_PHOTO);
        }

    }
    public boolean createPhotoFileName() {
        if (currentPhotoName == null) {
            GregorianCalendar gcal = new GregorianCalendar();
            gcal.get(Calendar.DAY_OF_MONTH);
            StringBuilder dateString = new StringBuilder();
            dateString.append(gcal.get(Calendar.YEAR));
            dateString.append(gcal.get(Calendar.MONTH));
            dateString.append(gcal.get(Calendar.DAY_OF_MONTH));


            currentPhotoName = "IMG_" + String.valueOf(mLastLocation.getLatitude()) + "_" + String.valueOf(mLastLocation.getLongitude()) + "_" + dateString.toString() + ".jpg";
        }
        File externalDir = this.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (mPhotoFile == null){
            mPhotoFile = new File(externalDir, currentPhotoName);
        }
        return true;
    }
    private void updatePhotoView() {
        if (mPhotoFile == null || !mPhotoFile.exists()) {
            mPhotoView.setImageDrawable(null);
        } else {
            mbitmap = PictureUtils.getScaledBitmap(
                    mPhotoFile.getPath(), this);
            mPhotoView.setImageBitmap(mbitmap);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK) {
            return;
        }



         if (requestCode == REQUEST_PHOTO) {
            updatePhotoView();
        }
    }

    @Override
    public void onConnected(Bundle bundle) {
        if(newForm) {
            startIntentService();
        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    public HashMap<String,String> encodeForm() {
        HashMap<String,String> data =new HashMap<>() ;

        data.put("address",addrsTV.getText().toString());
        data.put("type",spinnerType.getSelectedItem().toString());
        data.put("depth",spinnerDepth.getSelectedItem().toString());
        data.put("latitude",String.valueOf(mLastLocation.getLatitude()));
        data.put("longitude",String.valueOf(mLastLocation.getLongitude()));
        if (mbitmap != null) {
            String imageBase64 = ImageBase64.encode(mbitmap);

            data.put("image","teste");
        }
        return data;
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Toast.makeText(this, "Error GoogleAPI " + connectionResult.toString(), Toast.LENGTH_SHORT).show();
        // Return false so that we don't consume the event and the default behavior still occurs
        // (the camera animates to the user's current position).

    }
    protected void startIntentService() {
        Intent intent = new Intent(this, FetchAddressIntentService.class);
        intent.putExtra(Constants.RECEIVER, mResultReceiver);
        intent.putExtra(Constants.LOCATION_DATA_EXTRA, mLastLocation);
        showToast(getString(R.string.lookingAddr));
        startService(intent);
    }

    /**
     * Shows a toast with the given text.
     */
    protected void showToast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }


    class AddressResultReceiver extends ResultReceiver {
        public AddressResultReceiver(Handler handler) {
            super(handler);
        }

        @Override
        protected void onReceiveResult(int resultCode, Bundle resultData) {

            // Display the address string
            // or an error message sent from the intent service.
            String temOut = resultData.getString(Constants.RESULT_DATA_KEY);
            EditText addrsTV = (EditText) findViewById(R.id.editTextAddr);


            // Show a toast message if an address was found.
            if (resultCode == Constants.SUCCESS_RESULT && temOut != null) {
                addrsTV.setText(temOut, TextView.BufferType.SPANNABLE);
                addrsTV.setEnabled(true);
            }

        }


    }
    private class LocalAsyncResponse implements AsyncResponse {

        @Override
        public void processFinish(String s) {
            Toast.makeText(reportActivity.this,s,Toast.LENGTH_LONG).show();
            Log.d(Constants.LOGNAME,s);
            mUploadButton.setEnabled(true);
        }
    }

}
