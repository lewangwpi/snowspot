package com.example.isamu.snowslayer;

/**
 * Created by isamu on 4/3/2016.
 */
public final class Constants {
    public static final int SUCCESS_RESULT = 0;
    public static final int FAILURE_RESULT = 1;
    public static final String PACKAGE_NAME =
            "com.google.android.gms.location.sample.locationaddress";
    public static final String RECEIVER = PACKAGE_NAME + ".RECEIVER";
    public static final String RESULT_DATA_KEY = PACKAGE_NAME +
            ".RESULT_DATA_KEY";
    public static final String LOCATION_DATA_EXTRA = PACKAGE_NAME +
            ".LOCATION_DATA_EXTRA";
    public static final String URL_UPDATE = "http://isamubr.net16.net/snowslayer/update.php";
    public static final String URL_QUERY = "http://isamubr.net16.net/snowslayer/query_report.php";
    public static final String URL_DELETE = "http://isamubr.net16.net/snowslayer/delete.php";
    public static final String LOGNAME = "SNOWAPPLOG";


}
